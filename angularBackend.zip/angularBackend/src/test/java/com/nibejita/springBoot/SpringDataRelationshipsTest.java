package com.nibejita.springBoot;

import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.nibejita.springBoot.controller.EnimeCharacterController;
import com.nibejita.springBoot.module.Enime;
import com.nibejita.springBoot.service.EnimeCharacterService;
import org.hamcrest.Matchers;



@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class SpringDataRelationshipsTest {
	
	
	
	private MockMvc mockMvc;
	
	@Mock
    private EnimeCharacterService enimeCharacterService;

    @InjectMocks
    private EnimeCharacterController enimeCharacterController;
    
    @Before
    public void setUp() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(enimeCharacterController)
                .build();
    }
  
    		
    		
    @Test
    public void testPost() throws Exception {
        Enime enime=new Enime();
        enime.setEnimeName("naruto");
        
        String json ="{\n" +
                "  \"enimeName\": \"naruto\",\n" +
                "}";
        
        mockMvc.perform(MockMvcRequestBuilders.post("/EnimeCharacter/insertEnime").contentType("application/json").content(json)).andExpect(MockMvcResultMatchers.status().isOk()).
        andExpect(jsonPath("$.enimeName", Matchers.is("naruto")));
        
        verify(enimeCharacterService).insertEnime(enime);
    }
	
	
	

}
