package com.nibejita.springBoot.module;

import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.nibejita.springBoot.exception.EnimeInvalidException;

@Entity	
@Table(name="EnimeCharacter")
public class EnimeCharacter {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column
	private String characterFirstName;
	
	@Column
	private String characterLastName;
	
	@ManyToOne
	private Enime animeName;

	protected EnimeCharacter() {
		
	}

	


	public EnimeCharacter(String characterFirstName, String characterLastName, Enime animeName) {
		super();
		this.characterFirstName = characterFirstName;
		this.characterLastName = characterLastName;
		this.animeName = animeName;
	}

	


	public void setCharacterFirstName(String characterFirstName) {
		this.characterFirstName = characterFirstName;
	}




	public void setCharacterLastName(String characterLastName) {
		this.characterLastName = characterLastName;
	}




	public void setAnimeName(Enime animeName) {
		this.animeName = animeName;
	}




	public long getId() {
		return id;
	}




	public String getCharacterFirstName() {
		return characterFirstName;
	}




	public String getCharacterLastName() {
		return characterLastName;
	}




	public Enime getAnimeName() {
		return animeName;
	}




	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((characterFirstName == null) ? 0 : characterFirstName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EnimeCharacter other = (EnimeCharacter) obj;
		if (characterFirstName == null) {
			if (other.characterFirstName != null)
				return false;
		} else if (!characterFirstName.equals(other.characterFirstName))
			return false;
		return true;
	}
	

	
	
	


	

	

	
	
	

}
