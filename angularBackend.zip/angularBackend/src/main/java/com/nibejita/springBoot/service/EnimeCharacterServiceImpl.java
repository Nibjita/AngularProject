package com.nibejita.springBoot.service;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nibejita.springBoot.exception.EnimeInvalidException;
import com.nibejita.springBoot.module.Enime;
import com.nibejita.springBoot.module.EnimeCharacter;
import com.nibejita.springBoot.repository.EnimeCharacterRepository;
import com.nibejita.springBoot.repository.EnimeRepository;

@Service
public class EnimeCharacterServiceImpl implements EnimeCharacterService {

	@Autowired
	private EnimeCharacterRepository enimeCharacterRepository;

	@Autowired
	private EnimeRepository enimeRepository;

	@Override
	public String insertEnimeCharacter(EnimeCharacter enimeChar, String enimeName) throws Exception {
		Iterator<Enime> enimes = enimeRepository.findAll().iterator();
		while (enimes.hasNext()) {
			if (enimes.next().getEnimeName().equals(enimeName)) {
				Enime enime = enimes.next();
				enimeCharacterRepository.save(enimeChar);
				enime.getEnimeCharacters().add(enimeChar);
				enimeRepository.save(enime);
				return "Enime Character "+enimeChar+" successfully register in "+enimeName;
			} else
				throw new EnimeInvalidException("The enime "+ enimeName +" film/series not available");

		}

		throw new EnimeInvalidException("enime films/series not available");

	}

	@Override
	public boolean deleteEnime(long id) throws Exception {
		enimeCharacterRepository.delete(
				enimeCharacterRepository.findById(id).orElseThrow(() -> new EnimeInvalidException("Invalid Enime id")));
		return true;

	}

	@Override
	public EnimeCharacter updateEnime(long id, EnimeCharacter enime) throws Exception {
		EnimeCharacter enimeResult = enimeCharacterRepository.findById(id)
				.orElseThrow(() -> new EnimeInvalidException("Invalid Enime id"));
		enimeResult.setAnimeName(enime.getAnimeName());
		enimeResult.setCharacterFirstName(enime.getCharacterFirstName());
		enimeResult.setCharacterLastName(enime.getCharacterLastName());
		return enimeCharacterRepository.save(enimeResult);

	}

	@Override
	public EnimeCharacter findById(long id) throws Exception {
		return enimeCharacterRepository.findById(id).orElseThrow(() -> new EnimeInvalidException("Invalid Enime id"));
		
	}

	@Override
	public EnimeCharacter findByName(String name) throws Exception {
		return enimeCharacterRepository.findBycharacterFirstName(name)
				.orElseThrow(() -> new EnimeInvalidException("Invalid Enime id"));
	}

	@Override
	public List<EnimeCharacter> findAll() {
		return enimeCharacterRepository.findAll();
	}

	@Override
	public Enime insertEnime(Enime enime) throws EnimeInvalidException {
		if(enimeRepository.findAll().stream().anyMatch(enimes->enime.getEnimeName().equals(enime.getEnimeName()))) {
			throw new EnimeInvalidException("The enime "+enime.getEnimeName()+" film/series already present");
		}
		return enimeRepository.save(enime);
	}

}
