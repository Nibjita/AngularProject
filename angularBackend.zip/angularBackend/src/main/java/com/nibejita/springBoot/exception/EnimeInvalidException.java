package com.nibejita.springBoot.exception;

public class EnimeInvalidException extends Exception {

	public EnimeInvalidException() {
		// TODO Auto-generated constructor stub
	}

	public EnimeInvalidException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EnimeInvalidException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public EnimeInvalidException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EnimeInvalidException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
