package com.nibejita.springBoot.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;


import org.springframework.stereotype.Repository;

import com.nibejita.springBoot.module.EnimeCharacter;


//@Repository
//@Transactional
//public class EnimeCharacterDAOService {
//	
//	@PersistenceContext
//	private EntityManager entityManager;
//	
//	public void insert(EnimeCharacter enimeCharacter) {
//		//open Transaction
//		 entityManager.persist(enimeCharacter);
//		 //now enimeCharacter inside persistance context
//		 //close TRansaction
//	}
//}
