package com.nibejita.springBoot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nibejita.springBoot.module.Enime;

@Repository
public interface EnimeRepository extends JpaRepository<Enime, Long> {

}
