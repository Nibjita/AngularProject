package com.nibejita.springBoot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
import org.springframework.stereotype.Repository;

import com.nibejita.springBoot.module.EnimeCharacter;


@Repository
public interface EnimeCharacterRepository extends JpaRepository<EnimeCharacter,Long> {
	
	Optional<EnimeCharacter> findBycharacterFirstName(String characterFirstName);

}
