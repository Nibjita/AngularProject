package com.nibejita.springBoot.controller;

import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nibejita.springBoot.exception.EnimeInvalidException;
import com.nibejita.springBoot.module.Enime;
import com.nibejita.springBoot.module.EnimeCharacter;
import com.nibejita.springBoot.service.EnimeCharacterService;


@CrossOrigin(origins="http://localhost:4200")
//@CrossOrigin(origins="http://localhost:3000")     React
@RestController
@RequestMapping("EnimeCharacter/")
public class EnimeCharacterController {
	
	@Autowired
	private EnimeCharacterService enimeCharacterService; 
	
	@GetMapping("/getAllCharater")
	public List<EnimeCharacter> getAllCharater(){	
		//return enimeCharacterService.findAll().stream().collect(Collectors.toList());
		return enimeCharacterService.findAll();
		
	}
	
	
	@PostMapping("/insertCharacter/{animeName}")
	public String insertCharacter(@RequestBody EnimeCharacter character,@PathVariable String animeName ) throws Exception {
		return enimeCharacterService.insertEnimeCharacter(character,animeName);
	}
	
	@PostMapping("/insertEnime")
	public Enime insertEnime(@RequestBody Enime enime ) throws Exception {
		return enimeCharacterService.insertEnime(enime);
	}
	
	
	@DeleteMapping("/deleteCharacter/{id}")
	public boolean deleteCharacter(@PathVariable long id) throws Exception {
		return enimeCharacterService.deleteEnime(id);
	}
	
	
	@PostMapping("/updateCharacter/EnimeName/id")
	public EnimeCharacter updateEnime(@RequestBody EnimeCharacter enimeChar,@PathVariable long id) throws Exception {
		
		return enimeCharacterService.updateEnime(id, enimeChar);
	}
	
	@GetMapping("/findById/{id}")
	public EnimeCharacter findById(long id) throws Exception{
		return enimeCharacterService.findById(id);
		
	}
	
	@GetMapping("/findByName/{name}")
	public EnimeCharacter findByName(String name) throws Exception{
		return enimeCharacterService.findByName(name);
	}
	
	
	

	
	

}
