package com.nibejita.springBoot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.nibejita.springBoot.module.Enime;
import com.nibejita.springBoot.module.EnimeCharacter;
import com.nibejita.springBoot.repository.EnimeCharacterRepository;


@SpringBootApplication
public class AngularBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AngularBackendApplication.class, args);
	}



}
