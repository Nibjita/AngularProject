package com.nibejita.springBoot.service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.nibejita.springBoot.exception.EnimeInvalidException;
import com.nibejita.springBoot.module.Enime;
import com.nibejita.springBoot.module.EnimeCharacter;


public interface EnimeCharacterService {
	
	public Enime insertEnime(Enime enime) throws EnimeInvalidException;
	
	public String insertEnimeCharacter(EnimeCharacter enimeChar, String animeName) throws Exception;
	
	public boolean deleteEnime(long id) throws Exception;
	
	public EnimeCharacter updateEnime(long id,EnimeCharacter enime) throws Exception;
	
	public EnimeCharacter findById(long id) throws Exception;
	
	public EnimeCharacter findByName(String name) throws Exception;
	
	public List<EnimeCharacter> findAll();
	
	

}
