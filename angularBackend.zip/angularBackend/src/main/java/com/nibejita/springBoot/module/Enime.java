package com.nibejita.springBoot.module;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Enime {

	


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long enimeId;
	
	@Column
	private String enimeName;
	
	@OneToMany(mappedBy = "animeName")
	private Set<EnimeCharacter> enimeCharacters;
	
	public Enime(long enimeId, String enimeName, Set<EnimeCharacter> enimeCharacters) {
		super();
		this.enimeId = enimeId;
		this.enimeName = enimeName;
		this.enimeCharacters = enimeCharacters;
	}

	public Enime() {
		
	}

	public long getEnimeId() {
		return enimeId;
	}

	public String getEnimeName() {
		return enimeName;
	}

	public Set<EnimeCharacter> getEnimeCharacters() {
		return enimeCharacters;
	}

	public void setEnimeId(long enimeId) {
		this.enimeId = enimeId;
	}

	public void setEnimeName(String enimeName) {
		this.enimeName = enimeName;
	}

	public void setEnimeCharacters(Set<EnimeCharacter> enimeCharacters) {
		this.enimeCharacters = enimeCharacters;
	}
	
	
	
	
	
	
	
	
}
