package com.nibejita.springBoot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import com.nibejita.springBoot.module.EnimeCharacter;
import com.nibejita.springBoot.repository.*;

//public class EnimeCharacterCommandLneRunner implements CommandLineRunner {
//	
//	
//	@Autowired
//	private EnimeCharacterDAOService EnimeCharacterDAOService;
//
//	@Override
//	public void run(String... args) throws Exception {
//		EnimeCharacterDAOService.insert(new EnimeCharacter("Naruto","Uzumaki","Naruto"));
//		EnimeCharacterDAOService.insert(new EnimeCharacter("Midoriya","Uzuki","My Hero Academy"));
//		EnimeCharacterDAOService.insert(new EnimeCharacter("Sasuke","Uchiha","Naruto"));
//
//	}
//
//}
